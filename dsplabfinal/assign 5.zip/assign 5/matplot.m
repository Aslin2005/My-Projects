fs = 10000;
OUTPUT_SCALE = 2^28;
PLOT_TIME_MS = 15;

signal_names = {'950', '1100', '2000'};
methods = {'direct', 'optimized', 'genvar'};
method_titles = {'Direct', 'Optimized', 'Genvar'};

fig = figure('Name','Verilog FIR Outputs Using Pipeline (15ms)', ...
    'Position',[50,50,1600,1000],'PaperPositionMode','auto');

for s = 1:3
    sig = signal_names{s};
    
    for m = 1:3
        meth = methods{m};
        
        % Your filename format
        verilog_file = sprintf('out_%s%s.txt', sig, meth);

        subplot(3, 3, (s-1)*3 + m);
        
        samples_15ms = round(PLOT_TIME_MS * fs / 1000);

        if exist(verilog_file,'file')
            y_v = load(verilog_file);
            
            L = min(length(y_v), samples_15ms);
            
            y_v_plot = y_v(1:L) / OUTPUT_SCALE;
            t_plot = (0:L-1)/fs * 1000;
            
            plot(t_plot, y_v_plot, 'r-', 'LineWidth', 1.2);
            title(sprintf('%s Hz - %s', sig, method_titles{m}), 'FontSize', 11);
            
        else
            text(0.5, 0.5, sprintf('Missing:\n%s', verilog_file), ...
                'HorizontalAlignment', 'center', 'FontSize', 10);
            title(sprintf('%s Hz - %s', sig, method_titles{m}), 'FontSize', 11);
        end
        
        xlim([0 PLOT_TIME_MS]);
        xlabel('Time (ms)','FontSize',10);
        ylabel('Amplitude','FontSize',10);
        grid on;
        set(gca,'FontSize',10);
    end
end

sgtitle(sprintf('Verilog FIR Outputs (3 Signals x 3 Methods, %d ms)', ...
    PLOT_TIME_MS), 'FontSize', 14, 'FontWeight', 'bold');

print(fig, 'verilog_only_9subplots_15ms', '-dpng', '-r150');