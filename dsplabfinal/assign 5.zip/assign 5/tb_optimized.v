`timescale 1ns / 1ps

module tb_optimized;

reg clk;
reg rst;
reg signed [15:0] x_in;
wire signed [39:0] y_out;

// Signal memory
reg signed [15:0] x_signal1 [0:999];
reg signed [15:0] x_signal2 [0:999];
reg signed [15:0] x_signal3 [0:999];

integer i;
integer fid_1, fid_2, fid_3;
integer dummy_1, dummy_2, dummy_3;
integer fid_out1, fid_out2, fid_out3;

optimized_pipeline uut (
    .clk(clk),
    .rst(rst),
    .x_in(x_in),
    .y_out(y_out)
);

// Clock generation
initial clk = 0;
always #5 clk = ~clk; // 100 MHz clock

// Simulation
initial begin
    // Load input signals (UPDATED FILE NAMES)
    fid_1 = $fopen("signal_950hz.txt","r");
    for(i = 0; i < 1000; i = i + 1) begin
        dummy_1 = $fscanf(fid_1,"%d",x_signal1[i]);
    end
    $fclose(fid_1);

    fid_2 = $fopen("signal_1100hz.txt","r");
    for(i = 0; i < 1000; i = i + 1) begin
        dummy_2 = $fscanf(fid_2,"%d",x_signal2[i]);
    end
    $fclose(fid_2);

    fid_3 = $fopen("signal_2000hz.txt","r");
    for(i = 0; i < 1000; i = i + 1) begin
        dummy_3 = $fscanf(fid_3,"%d",x_signal3[i]);
    end
    $fclose(fid_3);

    // Open output files (UPDATED FILE NAMES)
    fid_out1 = $fopen("out_950.txt","w");
    fid_out2 = $fopen("out_1100.txt","w");
    fid_out3 = $fopen("out_2000.txt","w");

    // Reset
    rst = 1;
    #20;
    rst = 0;

    // Process sinewave1
    for(i = 0; i < 1000; i = i + 1) begin
        x_in = x_signal1[i];
        #10; // Wait for one clock cycle
        $fwrite(fid_out1, "%d\n", y_out);
    end

    // Reset for next signal
    rst = 1;
    #20;
    rst = 0;

    // Process sinewave2
    for(i = 0; i < 1000; i = i + 1) begin
        x_in = x_signal2[i];
        #10; // Wait for one clock cycle
        $fwrite(fid_out2, "%d\n", y_out);
    end

    // Reset for next signal
    rst = 1;
    #20;
    rst = 0;

    // Process sinewave3
    for(i = 0; i < 1000; i = i + 1) begin
        x_in = x_signal3[i];
        #10; // Wait for one clock cycle
        $fwrite(fid_out3, "%d\n", y_out);
    end

    // Close output files and finish simulation
    $fclose(fid_out1);
    $fclose(fid_out2);
    $fclose(fid_out3);
    $finish;
end

endmodule