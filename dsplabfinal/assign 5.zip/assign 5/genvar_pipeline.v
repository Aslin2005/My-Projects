module genvar_pipeline (
    input  wire                clk,
    input  wire                rst,
    input  wire signed [15:0]  x_in,
    output wire signed [39:0]  y_out
);

parameter TAPS = 100;

// Filter coefficients (Q2.14 format)
wire signed [15:0] h [0:TAPS-1];

assign h[0]  = -16'sd3;
assign h[1]  = -16'sd7;
assign h[2]  = -16'sd9;
assign h[3]  = -16'sd8;
assign h[4]  = -16'sd3;
assign h[5]  =  16'sd4;
assign h[6]  =  16'sd11;
assign h[7]  =  16'sd15;
assign h[8]  =  16'sd14;
assign h[9]  =  16'sd6;
assign h[10] = -16'sd7;
assign h[11] = -16'sd21;
assign h[12] = -16'sd29;
assign h[13] = -16'sd26;
assign h[14] = -16'sd11;
assign h[15] =  16'sd13;
assign h[16] =  16'sd38;
assign h[17] =  16'sd52;
assign h[18] =  16'sd47;
assign h[19] =  16'sd20;
assign h[20] = -16'sd22;
assign h[21] = -16'sd64;
assign h[22] = -16'sd87;
assign h[23] = -16'sd78;
assign h[24] = -16'sd33;
assign h[25] =  16'sd36;
assign h[26] =  16'sd104;
assign h[27] =  16'sd141;
assign h[28] =  16'sd125;
assign h[29] =  16'sd52;
assign h[30] = -16'sd57;
assign h[31] = -16'sd164;
assign h[32] = -16'sd222;
assign h[33] = -16'sd197;
assign h[34] = -16'sd83;
assign h[35] =  16'sd91;
assign h[36] =  16'sd263;
assign h[37] =  16'sd360;
assign h[38] =  16'sd324;
assign h[39] =  16'sd139;
assign h[40] = -16'sd156;
assign h[41] = -16'sd465;
assign h[42] = -16'sd661;
assign h[43] = -16'sd625;
assign h[44] = -16'sd285;
assign h[45] =  16'sd352;
assign h[46] =  16'sd1194;
assign h[47] =  16'sd2077;
assign h[48] =  16'sd2811;
assign h[49] =  16'sd3227;
assign h[50] =  16'sd3227;
assign h[51] =  16'sd2811;
assign h[52] =  16'sd2077;
assign h[53] =  16'sd1194;
assign h[54] =  16'sd352;
assign h[55] = -16'sd285;
assign h[56] = -16'sd625;
assign h[57] = -16'sd661;
assign h[58] = -16'sd465;
assign h[59] = -16'sd156;
assign h[60] =  16'sd139;
assign h[61] =  16'sd324;
assign h[62] =  16'sd360;
assign h[63] =  16'sd263;
assign h[64] =  16'sd91;
assign h[65] = -16'sd83;
assign h[66] = -16'sd197;
assign h[67] = -16'sd222;
assign h[68] = -16'sd164;
assign h[69] = -16'sd57;
assign h[70] =  16'sd52;
assign h[71] =  16'sd125;
assign h[72] =  16'sd141;
assign h[73] =  16'sd104;
assign h[74] =  16'sd36;
assign h[75] = -16'sd33;
assign h[76] = -16'sd78;
assign h[77] = -16'sd87;
assign h[78] = -16'sd64;
assign h[79] = -16'sd22;
assign h[80] =  16'sd20;
assign h[81] =  16'sd47;
assign h[82] =  16'sd52;
assign h[83] =  16'sd38;
assign h[84] =  16'sd13;
assign h[85] = -16'sd11;
assign h[86] = -16'sd26;
assign h[87] = -16'sd29;
assign h[88] = -16'sd21;
assign h[89] = -16'sd7;
assign h[90] =  16'sd6;
assign h[91] =  16'sd14;
assign h[92] =  16'sd15;
assign h[93] =  16'sd11;
assign h[94] =  16'sd4;
assign h[95] = -16'sd3;
assign h[96] = -16'sd8;
assign h[97] = -16'sd9;
assign h[98] = -16'sd7;
assign h[99] = -16'sd3;

// a_chain[0:TAPS] and b_chain[0:TAPS]: one extra entry at index 0 holds the inputs
// stage k reads a_chain[k], b_chain[k] and writes to a_chain[k+1], b_chain[k+1]
// no k-1 indexing anywhere — eliminates the a_chain[-1] warning
wire signed [15:0] a_chain [0:TAPS];
wire signed [39:0] b_chain [0:TAPS];

// Index 0: feed x_in and 0 directly into the first stage
assign a_chain[0] = x_in;
assign b_chain[0] = 40'sd0;

genvar k;
generate
    for (k = 0; k < TAPS; k = k + 1) begin : fir_stage
        fir_ffb u_ffb (
            .clk   (clk),
            .rst   (rst),
            .a_in  (a_chain[k]),
            .b_in  (b_chain[k]),
            .h_i   (h[k]),
            .a_out (a_chain[k+1]),
            .b_out (b_chain[k+1])
        );
    end
endgenerate

assign y_out = b_chain[TAPS];

endmodule


// fir_ffb: matches fir_pipeline stage exactly
//   Top rail Reg 1:  a1      <= a_in
//   Top rail Reg 2:  a_out   <= a1       (feeds next stage via a_chain)
//   Multiply reg:    mul_reg <= a_in * h_i
//   Sum reg:         b_out   <= b_in + mul_reg
module fir_ffb (
    input  wire                clk,
    input  wire                rst,
    input  wire signed [15:0]  a_in,
    input  wire signed [39:0]  b_in,
    input  wire signed [15:0]  h_i,
    output reg  signed [15:0]  a_out,
    output reg  signed [39:0]  b_out
);

    reg signed [15:0] a1;      // top-rail register 1
    reg signed [39:0] mul_reg; // registered multiplier output

    always @(posedge clk or posedge rst) begin
        if (rst) begin
            a1      <= 16'sd0;
            a_out   <= 16'sd0;
            mul_reg <= 40'sd0;
            b_out   <= 40'sd0;
        end
        else begin
            a1      <= a_in;           // top-rail reg 1
            a_out   <= a1;             // top-rail reg 2 (feeds next stage)
            mul_reg <= a_in * h_i;     // registered multiply
            b_out   <= b_in + mul_reg; // registered accumulate
        end
    end

endmodule